#!/usr/bin/env python

import ConfigParser, os

def parse_asset():
    return None

